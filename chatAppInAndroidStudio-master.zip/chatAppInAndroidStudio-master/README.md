# chatAppInAndroidStudio
This chat app is created in android studio using java and firebase
Some of the Output screens
![image](https://user-images.githubusercontent.com/64765400/119440006-5a5e0100-bcd8-11eb-88fb-0712bb223f78.png)

![image](https://user-images.githubusercontent.com/64765400/119440053-706bc180-bcd8-11eb-8bb7-2f0b6c5c43df.png)

![image](https://user-images.githubusercontent.com/64765400/119440063-75307580-bcd8-11eb-8da2-f3629f67c145.png)

![image](https://user-images.githubusercontent.com/64765400/119440078-7f527400-bcd8-11eb-97bc-287362d5d764.png)

![image](https://user-images.githubusercontent.com/64765400/119440082-82e5fb00-bcd8-11eb-9c99-3dfeae3e17ee.png)

![image](https://user-images.githubusercontent.com/64765400/119440112-91ccad80-bcd8-11eb-9bba-8e7c24034da4.png)

![image](https://user-images.githubusercontent.com/64765400/119440138-9b561580-bcd8-11eb-8cdf-76c3a6a4d902.png)

![image](https://user-images.githubusercontent.com/64765400/119440156-a14bf680-bcd8-11eb-9818-2533a8f1dfa4.png)
